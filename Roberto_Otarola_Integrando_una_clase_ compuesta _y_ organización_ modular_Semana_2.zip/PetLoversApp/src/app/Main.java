package app;

import model.Direccion;
import model.Dueno;
import model.Mascota;

public class Main {
    public static void main(String[] args) {

        Direccion direccionDueno = new Direccion("Los Robles", "456", "Valdivia");

        Dueno primerDueno = new Dueno("Camila Soto", "+56987654321", direccionDueno);

        Mascota paciente = new Mascota("Firulais", "Perro", 3, primerDueno);

        System.out.println(paciente.toString());
    }
}